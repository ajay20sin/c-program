#include<stdio.h>
int main()
{
    float a,b;
    printf("enter the value side\n");
    scanf("%f",&a);
    b=1.73*a*a/4;
    printf("the value of area of equilateral triangle is%f",b);
    return 0;

}
