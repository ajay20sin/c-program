#include <stdio.h>
int main()
{
    float a;
    printf("enter the no. of days\n");
    scanf("%f",&a);
    printf("days into year%f\n",a/365);
    printf("days into week %f\n",a/7);
    printf("days %f",a);
    return 0;

}