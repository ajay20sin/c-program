#include <stdio.h>
#include <math.h>
int main()
{
    int s;
    printf("enter the number\n");
    scanf("%d",&s);
    float c;
    c=sqrt(s);
    printf("the sqr root of no. is %f", c);
    return 0;
}