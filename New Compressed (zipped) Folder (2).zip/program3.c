#include<stdio.h>
void main()
{
    int a=10,b=2,c;
    printf("sum of no. is %d\n",c=a+b);
    printf("subtraction od no. is %d\n",c=a-b);
    printf("multiply of no. is %d\n",c=a*b);
    printf("divison od no. is %d\n",c=a/b);
}