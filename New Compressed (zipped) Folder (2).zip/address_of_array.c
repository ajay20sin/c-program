#include<stdio.h>
#include<math.h>

int main()
{
    int a[10],i,sum=0;
    for(i=0;i<=9;i++)
    {
        printf("%u\n",(a+i));
    }
    return 0;
}