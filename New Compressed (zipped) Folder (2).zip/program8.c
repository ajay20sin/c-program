#include<stdio.h>
int main()
{
    float c;
    printf("enter the value of temp in celcius\n");
    scanf("%f",&c);
    printf("the value if temp in fahrenheit is %f",c*1.8+32);
    return 0;
}