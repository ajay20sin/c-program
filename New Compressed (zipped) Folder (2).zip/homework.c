#include<stdio.h>
int main()
{
char ch;
int b;
float a;
printf("ch occupied %d size of char  %d\n",sizeof(ch),sizeof(char));

printf("b  occupied %d size of int   %d\n",sizeof(b),sizeof(int));

printf("a  occupied %d size of float %d\n",sizeof(a),sizeof(float));
return 0;  
}

