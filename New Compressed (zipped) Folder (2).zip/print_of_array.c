#include<stdio.h>
#include<math.h>

int main()
{
    int a[5]={1,2,3,4,5};
    printf("%d",a[4]);
    return 0;
}