#include<stdio.h>
void main()
{
    int a=4,b=5,c=a+b;
    printf("sum of a=%d & b=%d is c=%d",a,b,c);
}