#include<stdio.h>
int main()
{
    int length,breadth;
    printf("enter the value of length\n");
    scanf("%d",&length);
    printf("enter the the value of breadth\n");
    scanf("%d",&breadth);
    printf("the area is %d",length*breadth);
    return 0;

}